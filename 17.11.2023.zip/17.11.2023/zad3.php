<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obliczanie wartości bezwględnej</title>
</head>
<body>
    <?php
    $liczba = -15 
    $wartoscBezwzgledna = abs($liczba);
    echo "Wartość bewzględna z $liczba wynosi: $wartoscBezwzgledna";
    ?>

    <p>Autor: Jakub Galera </p>
</body>
</html>