<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Większa wartości</title>
</head>
<body>
    <?php
    $jednaZmienna = 31
    $drugaZmienna = 23
    if ($jednaZmienna > $drugaZmienna){
        echo"Większa wartość to:" . 
        $jednaZmienna;
    } else {
        echo "Większa wartość to:" . 
        $drugaZmienna
    }
    ?>

    <p>Autor: Jakub Galera </p>
</body>
</html>